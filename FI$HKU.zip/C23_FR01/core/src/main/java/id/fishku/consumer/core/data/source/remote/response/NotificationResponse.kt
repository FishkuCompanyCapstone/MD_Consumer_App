package id.fishku.consumer.core.data.source.remote.response

data class NotificationResponse(
    val success: Int,
    val failure: Int
)
