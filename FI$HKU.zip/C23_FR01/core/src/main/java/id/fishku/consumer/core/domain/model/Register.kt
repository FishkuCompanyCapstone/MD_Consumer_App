package id.fishku.consumer.core.domain.model

data class Register(
    val message: String? = null,
)