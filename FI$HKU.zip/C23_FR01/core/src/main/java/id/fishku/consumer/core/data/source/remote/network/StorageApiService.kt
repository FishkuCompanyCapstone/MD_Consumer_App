package id.fishku.consumer.core.data.source.remote.network

interface StorageApiService