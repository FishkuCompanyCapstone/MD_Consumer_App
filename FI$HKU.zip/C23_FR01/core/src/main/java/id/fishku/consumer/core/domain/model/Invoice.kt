package id.fishku.consumer.core.domain.model

data class Invoice(
    val message: String = "",
    val invoiceUrl: String? = null,
)