package id.fishku.consumer.core.domain.model

data class FishType(
    val fishID: Int,
    val name: String,
    val photoUrl: String
)