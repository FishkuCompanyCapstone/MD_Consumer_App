package id.fishku.consumer.core.domain.model

data class InputOrder(
    val message: String? = null,
    val orderingID: Int? = null,
)