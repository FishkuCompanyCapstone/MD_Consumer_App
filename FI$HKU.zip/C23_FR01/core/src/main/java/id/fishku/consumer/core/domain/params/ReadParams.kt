package id.fishku.consumer.core.domain.params

data class ReadParams(
    val chatId: String,
    val userEmail: String
)