package id.fishku.consumer.core.domain.params

data class ParamsToken(
    val token: String,
    val emailToken: String
)
