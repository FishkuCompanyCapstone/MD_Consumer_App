package id.fishku.consumer.core.data.source.local.entity

data class UserEntity(
    val id: Int,
    val name: String,
    val email: String,
    val phoneNumber: String,
    val address: String,
)