package id.fishku.consumer.core.domain.repository

import id.fishku.consumer.core.data.Resource
import id.fishku.consumer.core.data.source.remote.request.OtpRequest
import id.fishku.consumer.core.data.source.remote.response.DetectionFishResponse
import id.fishku.consumer.core.data.source.remote.response.OtpResponse
import id.fishku.consumer.core.domain.model.Fish
import id.fishku.consumer.core.domain.model.FishType
import id.fishku.consumer.core.domain.model.Market
import kotlinx.coroutines.flow.Flow
import okhttp3.MultipartBody

interface IFishRepository {
    fun getAllFish(): Flow<Resource<List<Fish>>>
    fun searchFishes(query: String): Flow<Resource<List<Fish>>>
    fun getDetailFish(fishID: Int): Flow<Resource<Fish>>
    fun uploadImageDetection(fishName: String?, image: MultipartBody.Part): Flow<Resource<DetectionFishResponse>>
    fun getListFishDetection(): Flow<Resource<List<FishType>>>
    fun sendCodeOtp(request: OtpRequest): Flow<Resource<OtpResponse>>

    /*TAMBAHAN TODO*/
    //fun getAllMarket(): Flow<Resource<List<Market>>>
}