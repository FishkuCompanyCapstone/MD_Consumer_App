package id.fishku.consumer.core.domain.chatparams

data class CreateParams(
    val userEmail: String,
    val sellerEmail: String
)