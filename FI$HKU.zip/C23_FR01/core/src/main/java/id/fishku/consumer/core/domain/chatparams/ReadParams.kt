package id.fishku.consumer.core.domain.chatparams

data class ReadParams(
    val chatId: String,
    val userEmail: String
)