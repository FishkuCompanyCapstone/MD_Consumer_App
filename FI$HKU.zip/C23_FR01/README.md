# Fishku Consumer - Android Development Repository

Repository Fishku Consumer for Android Development Team's

## User Interface
[Figma](https://www.figma.com/file/zw1PcImhnitHGJJzz3kz1u/FI%24HKU-APP)

## User Flow
![User Flow](https://raw.githubusercontent.com/fishku-id/.github/master/pictures/User-Flow.jpg)
