package id.fishku.consumer.model

class FishPricePrediction(
    val id: String,
    val provence: String,
    val fishType1: String,
    val fishType2: String,
    val fishType3: String,
    val fishType4: String,
    val fishType5: String,
    val fishType6: String,
    val fishPrice1: String,
    val fishPrice2: String,
    val fishPrice3: String,
    val fishPrice4: String,
    val fishPrice5: String,
    val fishPrice6: String,
)