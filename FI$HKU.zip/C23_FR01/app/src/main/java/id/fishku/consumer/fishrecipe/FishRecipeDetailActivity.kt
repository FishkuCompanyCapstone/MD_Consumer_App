package id.fishku.consumer.fishrecipe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import id.fishku.consumer.R

class FishRecipeDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fish_recipe_detail)
    }
}