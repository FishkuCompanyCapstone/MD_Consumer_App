package id.fishku.consumer.detailshop

class DetailShopViewModel {
}