package id.fishku.consumer.model

class FishRecipe (
    val id: String,
    val recipeName: String,
    val photoRecipeUrl: String
)