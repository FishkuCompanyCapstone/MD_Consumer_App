package id.fishku.consumer.model

class FishTypeDetection(
    val id: Int,
    val fishName: String,
    val photoUrl: String
)